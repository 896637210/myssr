$(function(){
	$(".bigL").delay(1000).animate({"left":"-10px","top":"-30px"});
//	.delay(500).animate({"left":"-1590px","top":"-800px","opacity":"0"},1000,function(){
//		$(".bigS").css({"display":"none"});
//	});
	$(".bigR").delay(1000).animate({"left":"10px","top":"30px"})
//	.delay(500).animate({"left":"1590px","top":"800px","opacity":"0"},1000);
	$(".bigS").click(function(){
		$(".bigL").animate({"left":"-1590px","top":"-800px","opacity":"0"},1000,function(){
		$(".bigS").css({"display":"none"});
		});
		$(".bigR").animate({"left":"1590px","top":"800px","opacity":"0"},1000);
		$("body").css({"overflow-y":"scroll"});
	});
//	$(".kai1").delay(1000).animate({"top":"40px"},1000,function(){
//		$(this).css({"display":"block"});
//	});
//	$(".kai2").delay(2000).animate({"top":"60px"},1000,function(){
//		$(this).css({"display":"block"});
//	});
//	$(".kai3").delay(2800).animate({"bottom":"100px"},1000,function(){
//		$(this).css({"display":"block"});
//	});
//	$(".kai4").delay(3400).animate({"bottom":"70px"},1000,function(){
//		$(this).css({"display":"block"});		
//	});
//	setTimeout(function(){
//		$(".kaiAll").css({"display":"none"});
//	},5000);

var ll;
setTimeout(function(){
	$("body").css({"background-size":$(window).width()+"px"});
    mask.style.backgroundPositionY=register.offsetTop*-1+"px";
	ll=$(window).width();
},0);
	

//背景图片转换
setInterval(function(){
var body=document.querySelector("body");
var i=Math.random()*3;
body.style.background="url(img/"+Math.round(i)+".jpg) no-repeat";
$("body").css({"background-size":ll+"px"});
},8000);

//居中
var register=document.querySelector(".register");
center(register);
var mask=document.querySelector(".mask");
center(mask);
var tishi=document.querySelector(".tishi");
window.addEventListener("resize",function(){
	center(mask);
	center(register);
	center(tishi);
})
 var p=0,t=0,and="+";  
window.addEventListener("scroll",function(){
	center(mask);
	center(tishi);
	center(register);
    mask.style.backgroundPositionY=register.offsetTop*-1+"px";
})

mask.style.backgroundSize=getWindowSize().width+"px";
//验证
var Fand;
var yan=0;
var pattern1=/^[0-9]{11}$/;
var pattern2=/^[0-9]{3,6}$/;
var db=openDatabase("benhuai3","1.0","myfirstwebsqldemo",function(){
	});
$("#use").blur(function(){
	if(pattern1.test($("#use").val())){
		db.transaction(function(tx){
			tx.executeSql("create table if not exists member1(id integer primary key asc,username text,notes text)");
			tx.executeSql("select * from member1 where username=?",[$("#use").val()],function(tx,data){
				if(data.rows.length){
					$("#use").css({"borderColor":"red"});			
				}else{
					$("#use").css({"borderColor":"#eee"});
					yan=1;
				}
			});
		});
	}else{
		$("#use").css({"borderColor":"red"});
	}
	
});

$("#pwd").blur(function(){
	if(pattern2.test($("#pwd").val())){
		$("#pwd").css({"borderColor":"#eee"});
	}else{
		$("#pwd").css({"borderColor":"red"});
	}
});

$("#butJ").click(function(){
	if(yan==1&&pattern1.test($("#use").val())&&pattern2.test($("#pwd").val())){
		Fand=$("#use").val()+","+$("#pwd").val();
		db.transaction(function(tx){
			tx.executeSql("create table if not exists member1(id integer primary key asc,username text,notes text)");
			tx.executeSql("insert into member1(username,notes)values('"+$("#use").val()+"','"+Fand+"')");
			sessionStorage.setItem("username",$("#use").val());
			location.href="http://192.168.2.233:8020/mysecond/index.html?__hbt=1499912918479";
		});
	}else{
		$(".tishi").fadeIn(500);
		center(tishi);
	}
	
});

$(".tishi").click(function(){
	$(".tishi").fadeOut(500);
});




});

//居中需要的函数
function center(element){
    element.style.left=((getWindowSize().width-element.offsetWidth)/2+getScrollSize().left)+"px";
    element.style.top=((getWindowSize().height-element.offsetHeight)/2+getScrollSize().top)+"px";
};
function getWindowSize(){
    return {
    "width":window.innerWidth||document.documentElement.clientWidth,
    "height":window.innerHeight||document.documentElement.clientHeight
    }
};
function getScrollSize(){
    return{
        "top":document.documentElement.scrollTop||document.body.scrollTop,
        "left":document.documentElement.scrollLeft||document.body.scrollLeft
    };
};