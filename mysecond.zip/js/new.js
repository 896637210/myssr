$(function(){
	//背景滚动
var xMove=0;
var backg=$(".col-1");
setInterval(function(){
	xMove+=-1;
	backg.css({"background-position-x":xMove+"px"});
	$(".zd-bg-1").css({"background-position-x":xMove+"px"});
},20);
	//导航条
$(".divskew li").each(function(i,v){
	$(v).click(function(){
		$(".divskew li").each(function(i,v){
			$(v).removeClass("li_active");
			$(v).children().removeClass("fonC");
		});
		$(this).addClass("li_active");
		$(this).children().addClass("fonC");
	});
});
//判断flash
function flashChecker() { 
var hasFlash = 0;　　　　 //是否安装了flash 
var flashVersion = 0;　　 //flash版本 
if(document.all) { 
var swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash'); 
if(swf) { 
hasFlash = 1; 
VSwf = swf.GetVariable("$version"); 
flashVersion = parseInt(VSwf.split(" ")[1].split(",")[0]); 
} 
} else { 
if(navigator.plugins && navigator.plugins.length > 0) { 
var swf = navigator.plugins["Shockwave Flash"]; 
if(swf) { 
hasFlash = 1; 
var words = swf.description.split(" "); 
for(var i = 0; i < words.length; ++i) { 
if(isNaN(parseInt(words[i]))) continue; 
flashVersion = parseInt(words[i]); 
} 
} 
} 
} 
return { 
f: hasFlash, 
v: flashVersion 
}; 
} 

var fls = flashChecker(); 
var s = ""; 
if(fls.f) {
	$(".flashAImg embed").css({"display":"block"});
	$(".flashAImg img").css({"display":"none"});
}
else{
	$(".flashAImg embed").css({"display":"none"});
	$(".flashAImg img").css({"display":"block"});
}

//tab页
$(".c3 .ul1 li").each(function(i,v){
	$(v).click(function(){
		$(".c3 .ul1 li").each(function(i,v){
			$(v).removeClass("motion");
			$(".c3 .uls").removeClass("cause");
		});
		$(this).addClass("motion");
		$($(".c3 .uls")[i]).addClass("cause");	
	});
		
});
//鼠标移动
var ground=true;
var ground2=true;
var groundtime=setInterval(function(){
	ground2=true;
	ground=true;
},3000);
var imgWidth=$(".advert ul li").width();
$($(".advert span")[0]).mouseover(function(evt){
	if(!ground){
		return ;
	}
	$(".advert ul").animate({"left":imgWidth+"px"},1000,function(){
		$(".advert ul").css({"left":0}).find("li:last").prependTo($(".advert ul"));
	});	

	ground=false;
});

$($(".advert span")[1]).mouseover(function(evt){
	if(!ground2){
		return ;
	}
	$(".advert ul").animate({"left":"-"+imgWidth+"px"},1000,function(){
		$(".advert ul").css({"left":0}).find("li:first").appendTo($(".advert ul"));
	});	
	ground2=false;
});
//nav

//防止多点击
var clicked=false;
setInterval(function(){
	clicked=false;
},3000);


///////////////////////////////////首页
$(".divskew").find("li:nth-child(1)").click(function(){
	 Allre();
//点击
	if(clicked){
		return ;
	}
//变量
	motol=3;
	$(".col-col-1").animate({"height":"0px"},500,function(){
	});
	$(".col-1").animate({"height":"800px"},2000,function(){
		$(".col-1").css({"height":"100%"});
	});
	$(".col-2").animate({"height":"800px"},2000,function(){
		$(".col-2").css({"height":"100%"});
		setTimeout(function(){
			$(".col-2").css({"display":"block"});	
		},1500);
	});
	backg=$(".col-1");
	$(".col-1").css({"background":"url(img/section_1_bg_1.jpg) repeat-x #00c3ff"});
//main
	$(".r1-1 img").fadeIn(1500);//fadeIn淡入
	$(".flashAA").fadeIn(1500);
//	$(".yasila2").fadeOut(500);
	$(".yasila2").css({"display":"none"});	
//mp4
	$(".videoP").css({"display":"block"});
	$(".videoP").animate({"height":"140px"},2000);
//角色
	$(".benChar").removeClass("benCharR")
	
	$(".wrap").animate({"backgroundColor":"#00c3ff"},1200,function(){
		$(".col-2").css({"background":"url(http://static.event.mihoyo.com/bh3_homepage/images/index/nav_list_bg.png) no-repeat"});
		$(".col-3").animate({"height":"639px"},2000,function(){
			$(".col-3").css({"height":"100%"});
//			$(".benChar").css({"display":"block"});
			$(".benChar").fadeIn(1000);
			setTimeout(function(){
			$(".sceen").css({"display":"block"});
			$(".advert").css({"display":"block"});
			},1500);
		});
	});	
	$(".tabss").css({"display":"none"});

	
	clicked=true;
});

////////////////////////////////作战

$(".divskew").find("li:nth-child(2)").click(function(){
	 Allre();
//点击
	if(clicked){
		return ;
	}
//变量
	motol=4;
	$(".col-col-1").animate({"height":"0px"},500,function(){
	});
	$(".col-2").animate({"height":"800px"},2000,function(){
		$(".col-2").css({"height":"100%"});
		setTimeout(function(){
			$(".col-2").css({"display":"block"});	
		},1500);
	});
	$(".col-1").animate({"height":"800px"},2000,function(){
		$(".col-1").css({"height":"100%"});
	});
	backg=$(".col__");
	$(".col-1").css({"background":"url(img/bg111111111.png) no-repeat #151515"});
//main
	$(".r1-1 img").fadeOut(500);  //fadeOut淡出
	$(".flashAA").fadeOut(500);
	$(".yasila2").fadeIn(500);
//mp4
	$(".videoP").animate({"height":"0px"},2000,function(){
		$(".videoP").css({"display":"none"});
	});
//角色
	$(".benChar").addClass("benCharR");
	$(".wrap").animate({"backgroundColor":"#151515"},1200,function(){
		$(".col-2").css({"background":"#151515"});
		$(".upLine").addClass("benCharR2");
		$(".col-3").animate({"height":"0px"},2000,function(){
			$(".sceen").css({"display":"none"});
			$(".advert").css({"display":"none"});
		});
	});	
	$(".tabC").animate({"height":"0px"},2000,function(){
		$(".tabC").delay(1500).animate({"height":"800px"},2000,function(){
			$(".tabC").css({"height":"100%"});
			$(".benChar").css({"display":"none"});
			$(".upLine").removeClass("benCharR2");		
			$(".upLine").addClass("benCharR");
			$(".tabss").css({"display":"block"});
		});
	});

	clicked=true;
	
	
});
//切换 游戏特色
$(".divskew").find("li:nth-child(5)").click(function(){
//点击
	if(clicked){
		return ;
	}
//main
	$(".wrap").css({"backgroundColor":"#00c3ff"});
	$(".r1-1 img").fadeOut(500);  //fadeOut淡出
	$(".flashAA").fadeOut(500);
//mp4
	$(".videoP").animate({"height":"0px"},2000,function(){
		$(".videoP").css({"display":"none"});
	});
//角色
	$(".col-2").animate({"height":"0px"},2000,function(){
		$(".col-2").css({"display":"none"});
	});
	$(".col-1").animate({"height":"0px"},2000,function(){
	});
	$(".col-3").animate({"height":"0px"},2000,function(){
		$(".sceen").css({"display":"none"});
		$(".advert").css({"display":"none"});
	});
	$(".col-col-1").animate({"height":"3000px"},2000,function(){
		$(".col-col-1").css({"height":"100%"});
	});
	
	
	clicked=true;
	
});



//tabs
$(".ul11 li").each(function(i,v){
	$(v).click(function(){
		$(".ul11 li").each(function(i,v){
			$(v).removeClass("clotherL");
			$(".tabss .conX").removeClass("clother");
		});
		$(this).addClass("clotherL");
		$($(".tabss .conX")[i]).addClass("clother");	
	});
		
});

//广告
$(".advert ul li").each(function(i,v){
	$(v).click(function(){
		$(this).find("p:nth-child(1)").toggleClass("shake");
		$(this).find("p:nth-child(2)").toggleClass("shake2");		
	});
	
	
	
	
});
//侧边栏
function flvfff(){
	$(".flv-bofang").css({"display":"none"});
	$(".sd2").css({"background":"transparent"});
	$(".flv-bofang")[0].pause();
	$(".nav-container").css({"z-index":"-3"});
}
var b=true;
$(".sd").click(function(){
	if(b==true){
		$(".sd").addClass("sd_kai");
		$(".sd").removeClass("sd_guan");
		return b=false;
	}else{
		$(".sd").addClass("sd_guan");
		$(".sd").removeClass("sd_kai");
		setTimeout(flvfff,1);
		return b=true;
	}
});
//var sd_g=$(".sd");
//var xxx=0
//var sss=setInterval(function(){
//	xxx+=1;
//	sd_g.css({"background-position-x":xxx+"px"});
//},10);

$(".input-fo").click(function(evt){
	evt.stopPropagation();
})
//验证

//web sql 数据库
var db=openDatabase("benhuai3","1.0","myfirstwebsqldemo",function(){
	});
var username=document.querySelector("#use");
var pwd=document.querySelector("#pwd");
var userbook=document.querySelector(".control-label");

var foUse,foPwd,Fand;
$("#use").keyup(function(){
	db.transaction(function(tx){
		tx.executeSql("create table if not exists member1(id integer primary key asc,username text,notes text)");
//		tx.executeSql("insert into member1(username,notes)values('123','123,123')");
	});
})
$("#use").blur(function(){
	if($.trim($("#use").val()).length==0){
		$(".f-top").addClass("has-error");
    	$(".f-top").removeClass("has-success");
	}else{
		$(".f-top").addClass("has-success");
		$(".f-top").removeClass("has-error");
	}
});

 $("#pwd").keyup(function(){

}); 
 $("#pwd").blur(function(){
 	if($.trim($("#pwd").val()).length==0){
		$(".f-center").addClass("has-error");
    	$(".f-center").removeClass("has-success");
	}else{
		$(".f-center").addClass("has-success");
		$(".f-center").removeClass("has-error");
	}
 });



function flvshitouming(){
	$(".flv-bofang").css({"display":"block"});
	$(".sd2").css({"background":"url(img/geziblack.png"});
	$(".flv-bofang")[0].play();
	$(".nav-container").css({"z-index":"10"});
}

$(".input-fo").keydown(function(event){
	switch (event.which) {
	case(13): 
			Fand=$("#use").val()+","+$("#pwd").val();
			if($.trim($("#use").val()).length==0){
				$(".f-top").addClass("has-error");
		    	$(".f-top").removeClass("has-success");
			}else{
				$(".f-top").addClass("has-success");
				$(".f-top").removeClass("has-error");            
				if($.trim($("#pwd").val()).length==0){
		    		$(".f-center").addClass("has-error");
		        	$(".f-center").removeClass("has-success");
		   	 }else{
		   	 		db.transaction(function(tx){
						tx.executeSql("select * from member1 where notes=?",[Fand],function(tx,data){
							console.log(Fand)
							if (data.rows.length) {
								$(".f-center").removeClass("has-error");
			        			$(".f-center").addClass("has-success");	
								setTimeout(flvshitouming,1);
								setTimeout(flvfff,10000);
								$(".input-fo").html("<span class='US'><img class='mate' src='img/01e21e584feb0aa8012060c8684da0.gif'/><b>"+$("#use").val()+"您好! <br>欢迎回来!</b></span>");
								$(".mate").click(function(){
									$(".input-fo").html('<div class="form-group f-top has-feedback"><label for="use" class="control-label">用户名</label><input type="text" class="form-control" id="use" maxlength="11"></div><div class="form-group f-center"><label for="pwd" class="control-label">密码</label><input type="password" class="form-control" id="pwd" maxlength="6"></div></div>');
								});
							}else{
								alert("用户名或密码不正确");					
							}
						});
					});
		    	}
			}
			break;
	};
});
//
if(sessionStorage.getItem("username")){
	$(".input-fo").html("<span class='US'><img class='mate' src='img/01e21e584feb0aa8012060c8684da0.gif'/><b>"+sessionStorage.getItem("username")+"您好! <br>欢迎回来!</b></span>");
	$(".mate").click(function(){
		$(".input-fo").html('<div class="form-group f-top has-feedback"><label for="use" class="control-label">用户名</label><input type="text" class="form-control" id="use" maxlength="11"></div><div class="form-group f-center"><label for="pwd" class="control-label">密码</label><input type="password" class="form-control" id="pwd" maxlength="6"></div></div>');
	});
}






//插入

//zd-4
var j=true;
$(".fifly7").click(function(){
	//点击
	if(clicked==true){
		return ;
	}
	if(j){
		$(".zd-4").animate({"height":"340px"},1000,function(){
			$(".zd-4").css({"height":"100%"});
		});
		clicked=true;
		return j=false;
	}else{
		$(".zd-4").animate({"height":"0px"},1000,function(){
		});
		clicked=true;
		return j=true;
	}

});
//zd-6
var g=true;
$(".zifly6").click(function(){
	//点击
	if(clicked==true){
		return ;
	}
	if(j){
		$(".zd-6").animate({"height":"340px"},1000,function(){
			$(".zd-6").css({"height":"100%"});
		});
		clicked=true;
		return j=false;
	}else{
		$(".zd-6").animate({"height":"0px"},1000,function(){
		});
		clicked=true;
		return j=true;
	}

});
//额外js
var motol=1;
$(".divskew").find("li:nth-child(5)").click(function(){
	$(".zd-1").addClass("changefilter");
	$(".content-w1 p").addClass("resetRight");
	$(".content-w1 h1").addClass("resetRight");
	motol=2;
});
var dialog=document.querySelector("dialog");
$(window).scroll(function(){
	center(dialog);
//	console.log($(document).scrollTop(),motol);
	if(motol==2){
		if(450<$(document).scrollTop()&&$(document).scrollTop()<550){
			$(".zd-2").addClass("changefilter");
			$(".content-w2 p").addClass("resetRight");
			$(".content-w2 h1").addClass("resetRight");
		}
		if(1700<$(document).scrollTop()&&$(document).scrollTop()<1800){
			$(".zd-3").addClass("changefilter");
			$(".content-w3 p").addClass("resetRight");
			$(".content-w3 h1").addClass("resetRight");
			var a=0;
			setInterval(function(){
				a+=1;
				$(".zd-3-ul").find("li:nth-child("+a+")").addClass("resetTop");
				if(a==6){
					a=0;
				}
//				console.log(a);
			},300);
		}
		if(2450<$(document).scrollTop()&&$(document).scrollTop()<2650){
			$(".zd-5").addClass("changefilter");
			$(".content-w5 p").addClass("resetRight");
			$(".content-w5 h1").addClass("resetRight");
			var b=0;
			setInterval(function(){
				b+=1;
				$(".zd-5-ul").find("li:nth-child("+b+")").addClass("resetRight");
				if(b==3){
					b=0;
				}
			},300);
		}
		if(3750<$(document).scrollTop()&&$(document).scrollTop()<3900){
			$(".zd-7").addClass("changefilter");
			$(".content-w7 h1").addClass("resetOpacity");
		}
	}
});

function Allre(){
	$(".col-col-1").children().removeClass("changefilter");
	$(".col-col-1 p").removeClass("resetRight");
	$(".col-col-1 h1").removeClass("resetRight");
	$(".zd-3-ul").children().removeClass("resetTop");
	$(".zd-5-ul").children().removeClass("resetTop");
}




//dialog
var ppa=document.querySelector(".ppa");
var close=document.querySelector(".close");

ppa.addEventListener("click",function(){
	dialog.show();
	center(dialog);
	$("dialog video")[0].play();
	$("dialog video")[1].play();
	$(".dialeft").addClass("vvv-move");
	$(".diaright").addClass("vvv-move");
//	console.log($(document).scrollTop())
//	setTimeout(function(){
//		document.documentElement.scrollTop=10;
//		document.body.scrollTop=10;
//	},100);
})
close.addEventListener("click",function(){
	$("dialog video")[0].pause();
	$("dialog video")[1].pause();
	$(".dialeft").removeClass("vvv-move");
	$(".diaright").removeClass("vvv-move");
	setTimeout(function(){
		dialog.close();
		
	},800);

})
//注册页面
$(".aijiang").one("click",function(){
	location.href="http://192.168.2.233:8020/Split%20screen/index.html?__hbt=1499912938479";
});


center(dialog);
//窗口滚动条滚动
 //窗口调整大小
 window.addEventListener("resize",function(){
	center(dialog);
 })
 window.addEventListener("load",function(){
	center(dialog);
 })



/**窗口中
 * 居中函数
 *
 * element：需要居中的元素
 */
function center(element){
    element.style.left=((getWindowSize().width-element.offsetWidth)/2+getScrollSize().left)+"px";
    element.style.top=((getWindowSize().height-element.offsetHeight)/2+getScrollSize().top)+"px";
}
/**父级元素下
 * 居中函数
 *
 * element：需要居中的元素
 */
function childCenter(element){
        element.style.marginLeft=(element.parentNode.clientWidth-element.offsetWidth)/2+"px";
        element.style.marginTop=(element.parentNode.clientHeight-element.offsetHeight)/2+"px";
}
/**
 *获取窗口尺寸
 * 不同浏览器。窗口的尺寸计算不同
 */
function getWindowSize(){
    return {
    "width":window.innerWidth||document.documentElement.clientWidth,
    "height":window.innerHeight||document.documentElement.clientHeight
    }
}
/**
 * 获取滚动条滚动的值
 */
function getScrollSize(){
    return{
        "top":document.documentElement.scrollTop||document.body.scrollTop,
        "left":document.documentElement.scrollLeft||document.body.scrollLeft
    }
}


//弹窗
$(".close111").click(function(){
	$(".conf").fadeOut(500);
});


















});
