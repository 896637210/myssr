function addZero(num){
    if(num<10){
        num="0"+num
    }
    return num;
}
/**
 *居中函数
 * element：需要居中的元素
 */
function center(element){
    element.style.left=((getWindowSiza().width-element.offsetWidth)/2+getScorllSize().left)+"px";
    element.style.top=((getWindowSiza().height-element.offsetHeight)/2+getScorllSize().top)+"px";
}
/**
 *获取窗口的尺寸
 *不同浏览器，窗口的尺寸计算不同
 */
function getWindowSiza(){
    return  {
        "width":window.innerWidth||document.documentElement.clientWidth,
        "height":window.innerHeight||document.documentElement.clientHeight
    };
}
/**
 *获取滚动条滚动的值
 */
    function getScorllSize(){
    return  {
        "top":document.documentElement.scrollTop||document.body.scrollTop,
        "left":document.documentElement.scrollLeft||document.body.scrollLeft
    };
}
/*邮箱验证*/
function valide_email(value){
    var pattern=/^[a-zA-Z0-9]+([\._-][a-z0-9]+)?@[a-z0-9]+([_-][a-z0-9])?\.[a-z]{2,11}(\.[a-z]{2,4})?$/i;
    if(pattern.test(value)){
        return true;
    }else {
        return false;
    }
}
/*修剪数据前后的空格*/
function trim(value){
    var pattern=/^\s*(.+?)\s*$/g;
    value=value.replace(pattern,"$1");
    return value;
}
function valide_pwd(value){
    var num=0;
    //value中没有数字
    if(!/[\d]/.test(value)){
        num+=1;
    }
    //value中没有小写字母
    if(!/[a-z]/.test(value)){
        num+=1;
    }
    //value中没有大写字母
    if(!/[A-Z]/.test(value)){
        num+=1;
    }
    //value中没有特殊符号
    if(!/[\W]/.test(value)){
        num+=1;
    }
    return num;
}
/*时间转换成秒分小时*/
	function timeFormat(duration,feedback){
		feedback.innerHTML=addZero(parseInt(duration/3600))
		+":"+addZero(parseInt(duration/60)%60)
		+":"+addZero(parseInt(duration%60));
	}
//设置localStorage
    function set(key,value){
        var currentTime=new Date().getTime();
        localStorage.setItem(key,JSON.stringify({"data":value,"time":currentTime}))
    }
/*获取locaStorage*/
    function  get(key,lifetime){
        var data=localStorage.getItem(key);
        if(data){
            var dataObj=JSON.parse(data);
            if(new Date().getTime()-dataObj.time>lifetime){
                localStorage.removeItem(key);
                console.log("数据已经过期")
            }else{
                return JSON.stringify(dataObj.data)
            }

        }
    }
    function setCookie(name,value,expires,path,domain,secure){
		//cookie="username=tom;exprires=d;domain=127.0.0.1;"
		//对cookie的name和value编码
		var cookieTxt=encodeURI(name)+"="+encodeURI(value);
		//如果expries是时间对象的话
		/*
			a instanceof b
			判断a是否是b的实例
			d就是Date的实例
			var d=new Date();
			d instanceof Date
		*/
		if(expires instanceof Date){
			cookieTxt+=";expires="+expires;
		}
		if(domain){
			cookieTxt+=";domain="+domain;
		}
		if(path){
			cookieTxt+=";path="+path;
		}
		if(secure){
			cookieTxt+=";secure";
		}
		document.cookie=cookieTxt;
	}
	function getCookie(name){
		var name=encodeURI(name);
		var str=document.cookie;
		var strStart=str.indexOf(name);
		var strEnd=str.indexOf(";",strStart);
		if(strEnd==-1){
			strEnd=str.length;
		}
		return decodeURI(str.substring(strStart+name.length+1,strEnd));
	}